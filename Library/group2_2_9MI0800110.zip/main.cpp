



#include "Commands.h"

int main() {
	Commands cmd;
	cmd.startProgram();

	return 0;
}